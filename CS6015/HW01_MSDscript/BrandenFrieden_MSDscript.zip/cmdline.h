#ifndef MyVec_hpp
#define MyVec_hpp

void use_arguments(int argc, char** argv);

#endif
