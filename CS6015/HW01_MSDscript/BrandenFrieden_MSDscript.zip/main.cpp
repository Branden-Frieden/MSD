#include "cmdline.h"
int main(int argc, char** argv) {
  use_arguments(argc, argv);
  return 0;
}
