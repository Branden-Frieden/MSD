extern "C"{
	void sayHello();
	void myPuts();
}
int main(int argc, char** argv) {
	sayHello();
	myPuts();
	return 0;
}
